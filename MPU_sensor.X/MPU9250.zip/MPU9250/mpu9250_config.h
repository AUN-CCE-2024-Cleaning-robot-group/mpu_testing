/* 
 * File:   mpu9250_config.h
 * Author: Mahmoud
 *
 * Created on November 22, 2023, 3:19 PM
 */

#ifndef MPU9250_CONFIG_H
#define	MPU9250_CONFIG_H

#ifdef	__cplusplus
extern "C" {
#endif

#include "configure.h"





#ifdef	__cplusplus
}
#endif

#endif	/* MPU9250_CONFIG_H */

