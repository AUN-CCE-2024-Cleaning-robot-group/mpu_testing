/* 
 * File:   mpu9250_interface.h
 * Author: Mahmoud
 *
 * Created on November 22, 2023, 3:17 PM
 */

#ifndef MPU9250_INTERFACE_H
#define	MPU9250_INTERFACE_H

#ifdef	__cplusplus
extern "C" {
#endif

#include "configure.h"
#include "mpu9250_config.h"
#include "mpu9250_private.h"


    //define array of 3 elements to store the gyro values
    extern float gyro[3];
    //define array of 3 elements to store the mag values
    extern  float mag[3];
    //define array of 3 elements to store the accel values
    extern float accel[3];

#include"configure.h"
#include "mpu9250_config.h"
#include "mpu9250_private.h"
#include "mpu9250_interface.h"

void mpu9250_writeByte(uint8_t reg, uint8_t data) ;
void mpu9250_readByte(uint8_t reg, uint8_t *data) ;
void read_gyro_word(uint8_t reg_h, uint8_t reg_l , int16_t *data) ;
void read_mag_word(uint8_t reg_h, uint8_t reg_l, int16_t *data ) ;
void mpu9250_read_gyro(float *gyro) ;
void mpu9250_read_magnometer(float *mag) ;
void mpu9250_read_accelerometer(float *accel) ;
void mpu9250_init() ;







#ifdef	__cplusplus
}
#endif

#endif	/* MPU9250_INTERFACE_H */

