#include"configure.h"
#include "mpu9250_config.h"
#include "mpu9250_private.h"
#include "mpu9250_interface.h"





void mpu9250_writeByte(uint8_t reg, uint8_t data)
{
    i2c_start();
    i2c_write(0xD0);
    i2c_write(reg);
    i2c_write(data);
    i2c_stop();
}
void mpu9250_readByte(uint8_t reg, uint8_t *data) {
    i2c_start(); 
    i2c_write(0xD0); 
    i2c_write(reg); 
    i2c_start(); 
    i2c_write(0xD1); 
    *data = i2c_read(0); // Performs a NACK on the final read 
    i2c_stop();
}


//function to read a 16 bit value from two consecutive registers of the MPU9250
//function to read a 16 bit value from two consecutive registers of the MPU9250
void read_word(uint8_t device_address, uint8_t reg_h, uint8_t reg_l, int16_t *data) {
    i2c_start();
    i2c_write(device_address ); // write the device address with write bit
    i2c_write(reg_h); // write the high byte register address
    
    i2c_start(); 
    
    i2c_write(device_address |0x01); // write the device address with read bit
    *data = (int16_t)(i2c_read() << 8); // read the high byte value and cast to signed
    i2c_stop(); // stop the I2C communication

    i2c_start();
    i2c_write(device_address  ); // write the device address with write bit
    
    i2c_write(reg_l); // write the low byte register address
    i2c_start(); 
    
    i2c_write(device_address |0x01 ); // write the device address with read bit
    *data |= i2c_read(0); // read the low byte value with NACK
    i2c_stop(); // stop the I2C communication
}
void read_gyro_word(uint8_t reg_h, uint8_t reg_l, int16_t *data) {
    read_word(MPU9250_ADDRESS, reg_h, reg_l, data);
}

void read_mag_word(uint8_t reg_h, uint8_t reg_l, int16_t *data) {
    read_word(AK8963_ADDRESS, reg_h, reg_l, data);
}


// A function to initialize MPU9250
void mpu9250_init() {
     

    // Write the configuration and power management values to the registers
    mpu9250_writeByte(CONFIG, CONFIG_VALUE);
    // Initialize the MPU9250
    mpu9250_writeByte(PWR_MGMT_1, PWR_MGMT_1_VALUE);
    mpu9250_writeByte(PWR_MGMT_2, PWR_MGMT_2_VALUE);
    // Enable the bypass mode to access the AK8963 directly
    mpu9250_writeByte(INT_PIN_CFG, INT_PIN_CFG_VALUE);
    // Wait for the device to stabilize
    delay_ms(100);
}




void mpu9250_read_gyro(float *gyro)
{

    // Read the gyro values
     read_gyro_word(GYRO_XOUT_H, GYRO_XOUT_L,&gyro[0] );
     read_gyro_word(GYRO_YOUT_H, GYRO_YOUT_L,&gyro[1] );
     read_gyro_word(GYRO_ZOUT_H, GYRO_ZOUT_L,&gyro[2] );
    // Convert the gyro values to degrees per second
    gyro[0] /= GYRO_SCALE;
    gyro[1] /= GYRO_SCALE;
    gyro[2] /= GYRO_SCALE;


}

void mpu9250_read_magnometer(float *mag)
{
    // Read the status of the mag data
    uint8_t status =0;
    mpu9250_readByte(ST1, &status);
    // Check if the data is ready
    if (status & 0x01) {
        // Read the mag values
         read_mag_word(MAG_XOUT_H, MAG_XOUT_L,&mag[0] );
         read_mag_word(MAG_YOUT_H, MAG_YOUT_L,&mag[1] );
         read_mag_word(MAG_ZOUT_H, MAG_ZOUT_L,&mag[2] );
        //  Convert the mag values to uT
        mag[0] /= MAG_SCALE;
        mag[1] /= MAG_SCALE;
        mag[2] /= MAG_SCALE;
    }
}

void mpu9250_read_accelerometer(float *accel)
{
    // Read the accel values
     read_gyro_word(ACCEL_XOUT_H, ACCEL_XOUT_L,&accel[0] );
     read_gyro_word(ACCEL_YOUT_H, ACCEL_YOUT_L,&accel[1] );
     read_gyro_word(ACCEL_ZOUT_H, ACCEL_ZOUT_L,&accel[2] );
    // Convert the accel values to g
    accel[0] /= ACCEL_SCALE;
    accel[1] /= ACCEL_SCALE;
    accel[2] /= ACCEL_SCALE;
}

// Deinit the mpu9250_module  enter sleep mode;

