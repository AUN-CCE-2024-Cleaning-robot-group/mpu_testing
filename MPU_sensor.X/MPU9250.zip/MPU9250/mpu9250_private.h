/* 
 * File:   mpu9250_private.h
 * Author: Mahmoud
 *
 * Created on November 22, 2023, 3:18 PM
 */

#ifndef MPU9250_PRIVATE_H
#define	MPU9250_PRIVATE_H

#ifdef	__cplusplus
extern "C" {
#endif
//Sensitivity= Full Scale Range/Digital Range
#define WHO_AM_I_MPU9250 0x75

#define GYRO_SCALE   131.0
#define ACCEL_SCALE  16384.0
#define MAG_SCALE    0.6

// MPU9250 I2C address pin is connected to GND
#define MPU9250_ADDRESS 0xD0


// Define the registers for configuration and power management
#define CONFIG 0x1A
#define PWR_MGMT_1 0x6B
#define PWR_MGMT_2 0x6C

// Define the values for configuration and power management
#define CONFIG_VALUE 0x03 // set the digital low pass filter to 41 Hz for gyro and 44 Hz for accel
#define PWR_MGMT_1_VALUE 0x01 // set the clock source to PLL with X axis gyroscope reference
#define PWR_MGMT_2_VALUE 0x00 // enable all sensors
    
// The address of the AK8963 device on the I2C bus
#define AK8963_ADDRESS 0x18
// The register address of the interrupt pin configuration
#define INT_PIN_CFG 0x37
// The value to enable the bypass mode of the MPU9250
#define INT_PIN_CFG_VALUE 0x02

#define ST1 0x02


// Define the registers for gyroscope data
#define GYRO_XOUT_H 0x43
#define GYRO_XOUT_L 0x44
#define GYRO_YOUT_H 0x45
#define GYRO_YOUT_L 0x46
#define GYRO_ZOUT_H 0x47
#define GYRO_ZOUT_L 0x48

// Define the registers for magnometer data
#define MAG_XOUT_L 0x03
#define MAG_XOUT_H 0x04
#define MAG_YOUT_L 0x05
#define MAG_YOUT_H 0x06
#define MAG_ZOUT_L 0x07
#define MAG_ZOUT_H 0x08

// Define the registers for accelerometer data
#define ACCEL_XOUT_H 0x3B
#define ACCEL_XOUT_L 0x3C
#define ACCEL_YOUT_H 0x3D
#define ACCEL_YOUT_L 0x3E
#define ACCEL_ZOUT_H 0x3F
#define ACCEL_ZOUT_L 0x40

#ifdef	__cplusplus
}
#endif

#endif	/* MPU9250_PRIVATE_H */

