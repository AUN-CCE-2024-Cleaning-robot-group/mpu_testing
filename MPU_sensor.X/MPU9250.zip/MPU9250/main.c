/* 
 * File:   mpu9250_config.h
 * Author: Mahmoud
 *
 * Created on November 22, 2023, 3:19 PM
 */
#include "configure.h"
#include "MPU9250/mpu9250_interface.h"
#include "mpu9250_private.h"

float gyro[3] = {0.0, 0.0, 0.0} ;
float mag[3] = {0.0, 0.0, 0.0}   ;
float accel[3] = {0.0, 0.0, 0.0}    ;
// Declare a variable to store the loop counter
void main() {



    set_tris_c(0x80);

    //Enable global interrupts
    enable_interrupts(GLOBAL);

    //Init the uart
    set_uart_speed(9600) ;

    output_float(PIN_B1);
    output_float(PIN_B0);


    printf(ANSI_COLOR_YELLOW"start of init  \n\r"ANSI_COLOR_RESET );

   //Init the mpu9250
    mpu9250_init();
    
    
    // Declare variables to store the sensor values

    uint32_t  i = 0;
    // Loop forever
     while (1) {
        // Read the gyro values
        
        mpu9250_read_gyro(gyro);

        // Read the mag values
        mpu9250_read_magnometer(mag);

        // Read the accel values
       mpu9250_read_accelerometer(accel);

        // Print the sensor values on the serial monitor
        printf(ANSI_COLOR_GREEN"Loop %lu:\n\r"ANSI_COLOR_RESET, i);

        printf("Gyro: X = %.3f, Y = %.3f, Z = %.3f (deg/s)\n\r", gyro[0], gyro[1], gyro[2]);

        printf("Mag: X = %.3f, Y = %.3f, Z = %.3f (uT)\n\r", mag[0], mag[1], mag[2]);

       printf(ANSI_COLOR_YELLOW"Accel: X = %.4f, Y = %.4f, Z = %.4f (g)\n\r"ANSI_COLOR_RESET, accel[0], accel[1], accel[2]);

        printf("\n\r");
        // Increment the loop counter
        i++;
        // Wait for 1 second
        delay_ms(200);
    }
    
}

//    while (1) {
//        // Read the gyro values
//        
//        mpu9250_read_gyro(gyro);
//
//        // Read the mag values
//        mpu9250_read_magnometer(mag);
//
//        // Read the accel values
//       mpu9250_read_accelerometer(accel);
//
//        // Print the sensor values on the serial monitor
//        printf(ANSI_COLOR_GREEN"Loop %lu:\n\r"ANSI_COLOR_RESET, i);
//
//        printf("Gyro: X = %.3f, Y = %.3f, Z = %.3f (deg/s)\n\r", gyro[0], gyro[1], gyro[2]);
//
//        printf("Mag: X = %.3f, Y = %.3f, Z = %.3f (uT)\n\r", mag[0], mag[1], mag[2]);
//
//       printf(ANSI_COLOR_YELLOW"Accel: X = %.4f, Y = %.4f, Z = %.4f (g)\n\r"ANSI_COLOR_RESET, accel[0], accel[1], accel[2]);
//
//        printf("\n\r");
//        // Increment the loop counter
//        i++;
//        // Wait for 1 second
//        delay_ms(100);
//    }